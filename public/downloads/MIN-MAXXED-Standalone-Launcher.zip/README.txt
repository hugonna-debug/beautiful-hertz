MIN-MAXXED Standalone Desktop Client
=======================================

To run MIN-MAXXED as a standalone app:
1. Extract the contents of this ZIP file into your local MIN-MAXXED repository root folder (where package.json and vite.config.ts are located).
2. Double-click "Launch_Standalone.bat" (on Windows) or run "Launch_Standalone.sh" (on macOS/Linux).
3. The launcher will ask if you want to check for and apply updates from the main branch.
   - If you choose Yes: It will automatically pull the latest commits, update npm dependencies, build the game, and start the local standalone Electron client.
   - If you choose No: It will start the local standalone Electron client using your current files instantly.
4. Enjoy MIN-MAXXED in full-screen standalone mode with maximum performance, zero browser overhead, and offline support!
